"""Odd exercise"""


def odd(x):
   """odd"""
   return x%2!=0
    

def main():
    data = input()
    print(odd(int(data)))

if __name__ == "__main__":
    main()
